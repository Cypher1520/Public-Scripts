﻿#***********************************************
#             Offboarding Tool                 #
#***********************************************
# Written By Chris Rockwell for AccessPipeline #
#***********************************************
# Steps:
# 
#*** Active Directory ***
# Disable users account
# Move it to Disabled users
# Remove all memberships and save an output of groups to a file located at "\\access-fs04\service$\ITSupport\_End_User_Services\DisabledUsersGroups"
# Reset Client's Password
# Sets user Description to date of disabled
# Prefix Username with "zz"
#
#*** Office 365 ***
# Convert users mailbox to shared
# Remove license
# Delegate people to the shared inbox
# Forward email message to 1 user
# Removes all mobile devices attached the users exchange online account
# Set Automatic reply on Mailbox to users Manager - External and Internal
#
#*************
# 
# Change Log:
#
# V1.0.3 - Corrected bad formatting
#
# V1.0.2 - Added Note in details about disabled date 
#        - Added steps list
#        - Set Automatic Reply on Shared Mailbox
#
# V1.0.1 - Added append command to csv printout for AD groups.
#
# V1.0 - Steps included:
# Active Directory - Disable Users, Move to disabled users, Save groups as CSV and then remove, Reset Clients password
# Office 365 - Convert to Shared mailbox, Remove License, Delegate people(s) to Shared Mailbox, Forward if requested, Remove all exchange active sync mobile devices


Import-module ActiveDirectory

Write-Host("`n")
$duser = Read-Host 'What is the identity [Account name ex. "crockwell"] of the User to be Offboarded?'
Write-Host("`n")
        Write-Host("********************************************************") -ForegroundColor Magenta
        Write-Host("This script will perform the following steps to the user:")
        Write-Host("Move User to") -NoNewline
        Write-Host(" 'Disabled Users'") -ForegroundColor Yellow -NoNewline
        Write-Host(" OU")
        Write-Host("Disable") -ForegroundColor Yellow -NoNewline
        Write-Host(" their AD Account")
        Write-Host("Remove") -NoNewline
        Write-Host(" ALL") -ForegroundColor Yellow -NoNewline
        Write-Host(" of group memberships except 'Domain Users'")
        Write-Host("Append 'zz' to the beginning of the users 'Name' and 'Display Name'")
        Write-Host("Ask you to reset the users password")
        Write-Host("********************************************************") -ForegroundColor Magenta
$confirm = Read-Host("Are you SURE you want to perform this action? [y/n]")
Write-Host("`n")
If($confirm -eq 'y')
    {
        $confirm2 = Read-Host("Are you REALLY SURE? [y/n]")
        Write-Host("`n")
        If($confirm2 -eq 'y')
	        {              
                Write-Host "Moving User to" -NoNewLine 
                Write-Host " Disabled Users" -ForegroundColor Yellow
                Get-ADUser $duser | Move-ADObject -targetpath (Get-ADOrganizationalUnit -filter "name -eq 'Disabled users'")
                Write-Host
                Write-Host ("Complete.") -ForegroundColor Green
                Write-Host "`n"
                
                Write-Host "User account is being" -NoNewLine
                Write-Host " Disabled" -ForegroundColor Yellow
                Disable-ADAccount -Identity $duser
                Write-Host
                Write-Host("Complete.") -ForegroundColor Green
            }
        If($confirm2 -eq 'y')
            {
                Write-Host `n
                Write-Host "Removing all Group Memberships except" -NoNewline
                Write-Host " 'Domain Users" -ForegroundColor Yellow
                (GET-ADUSER –Identity $duser –Properties MemberOf | Select-Object MemberOf).MemberOf | Out-File \\access-fs04\service$\ITSupport\_End_User_Services\DisabledUsersGroups\$duser.csv -Append
                $User = Get-ADUser $duser -Properties MemberOf
                $Groups = $User.memberOf | ForEach-Object {
                Get-ADGroup $_
                                          }
                        $Groups |ForEach-Object { 
                        Remove-ADGroupMember -Identity $_ -Members $User -Confirm:$false
                                }
                        Write-Host `n
                        Write-Host("Complete.") -ForegroundColor Green
                        Write-Host `n
            }

        If($confirm2 -eq 'y')
            {
                $date = Read-Host 'What is todays date - Numbers only (mm/dd/yyyy)?'
                Write-Host `n
                Write-Host "Adding todays date to details section"
                Set-AdUser -Identity $duser -Description "Disabled $date"

                                }
                        Write-Host `n
                        Write-Host("Complete.") -ForegroundColor Green
                        Write-Host `n
            }

        If($confirm2 -eq 'y')
            {
                $uname = Get-ADUser $duser | Select Name
                $uname2 = $uname.Name
                Write-Host "Appending" -NoNewLine
                Write-Host " 'zz'" -ForegroundColor Yellow -NoNewLine
                Write-Host " to users display names" -NoNewLine
                Rename-ADObject -identity (get-aduser $duser).distinguishedname -newname zz$uname2
                Set-ADUser $duser -DisplayName zz$uname2

                Write-Host `n
            }
        If($confirm2 -eq 'y')
            {
                Write-Host "You will now be asked to set a New Password for" -NoNewLine
                Write-Host " $duser" -ForegroundColor Yellow
                Set-ADAccountPassword -Identity $duser -Reset
                Write-Host "`n"
            }

Else
    {
    Write-Host ("Active Directory Portions Not Performed Please Restart if you would like to action these items") -ForegroundColor Red
    }


Write-Host "`n"
Write-Host "Active Directory Process complete, press" -NoNewline
Write-Host " [Enter] " -ForegroundColor Green -NoNewline
Write-Host "to Continue... " -NoNewline
$input = Read-Host

# *********************************************************************************************
# Stages Divider
# *********************************************************************************************

Write-Host "`n"
Write-Host "Beginning Office365 process"
Write-Host "press" -NoNewline
Write-Host " [Enter] " -ForegroundColor Green -NoNewline
Write-Host "to Continue... "
$input = Read-Host

$UserCredential = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
Import-PSSession $Session

Import-Module MSOnline
Connect-msolservice -credential $UserCredential

Get-Mailbox -identity $duser"@accesspipeline.com" | Get-MailboxStatistics | Select TotalItemSize
$continue = Read-Host("`nWould you like to continue with the conversion to a shared mailbox? [y/n]")
If($continue -eq 'y')
	{
		$yn = Read-Host("`nDoes anyone need access to this mailbox? [y/n]")
		Write-Host("`n")
		If($yn -eq 'y')
			{
				$access = Read-Host 'Will more than one person need access? [y/n]'
				Write-Host("`n")
				If($access -eq 'y')
					{
						$accessuser = @()
						$more = 'y'
						do
						{
							$user = Read-Host 'Please enter the user requiring access [email address(es)]'
							$accessuser += ,@($user)
							Write-Host("`n")
							$more = Read-Host 'add another? [y/n]'
							Write-Host("`n")
						}
						until($more -eq 'n')
					}
				Else
					{
						$accessuser = Read-Host 'Please enter the user to grant access [email address]'
					}
            }
    }
		Write-Host("`n")
		$fwd = Read-Host 'Does the email need to be forwarded? [y/n]'
		If($fwd -eq 'y')
			{
				$forward = Read-Host 'Enter email address or group to forward to.'
			}
		Write-Host("`n")
		Write-Host("Changing Mailbox to Shared...")
		Get-Mailbox -identity $duser | set-mailbox -type “Shared”
		Set-Mailbox $duser -ProhibitSendReceiveQuota 50GB -ProhibitSendQuota 49.75GB -IssueWarningQuota 49.5GB
		Write-Host("Complete.")
		Write-Host("`n")
		If($yn -eq 'y')
			{
				Write-Host("Adding Mailbox permissions...")
				foreach ($a in $accessuser)
					{
						Add-MailboxPermission $duser -User ((out-string -InputObject $a).Trim()) -AccessRights FullAccess
					}
				Write-Host("Complete.")
			}
		If($fwd -eq 'y')
			{
				Write-Host("Setting forwarding...")
				Set-Mailbox -Identity $duser -ForwardingSMTPAddress $forward
				Write-Host("Complete.")
			}
 		Write-Host("Removing assigned licenses...")
		$license = (Get-MSOLUser -UserPrincipalName $duser@accesspipeline.com).Licenses[0].AccountSkuId
		Set-MsolUserLicense -UserPrincipalName $duser@accesspipeline.com -RemoveLicenses $license
        
            Write-Host("Removing Mobile Devices from users Exchange account...")
            Get-MobileDevice -Mailbox $duser | ForEach { 
                                                        Remove-MobileDevice -Identity $_.Identity -Confirm 
                                                       }

                Write-Host ("Setting Automatic Reply for $duser@accesspipeline.com")
                Set-MailboxAutoReplyConfiguration $duser@accesspipeline.com -AutoReplyState Enabled -InternalMessage "Please be informed that this person is no longer with Access Pipeline.  If this is an important, Access Pipeline business related matter please email their manager at '$accessuser'" -ExternalMessage "Please be informed that this person is no longer with Access Pipeline.  If this is an important, Access Pipeline business related matter please email their manager at '$accessuser'"
        

    Write-Host "Process complete, press" -NoNewline
    Write-Host " [Enter]"  -ForegroundColor Green -NoNewline
    Write-Host " To exit..."
    
    Remove-PSSession $Session
    