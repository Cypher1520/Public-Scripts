Write-Host "`n"
Write-Host "Hidding users mailbox in EX2010"

$cred = Get-Credential access\adm-crockwell
$2010session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://access-ex05/powershell -Credential $cred
Import-PSSession $2010session

Set-RemoteMailbox -Identity jmanning -HiddenFromAddressListsEnabled $true

Remove-PSSession $2010session

	Write-Host `n
	Write-Host("Complete.") -ForegroundColor Cyan
	Write-Host `n

Write-Host "`n"
Write-Host "Exchange 2010 Process complete, press" -NoNewline
Write-Host " [Enter] " -ForegroundColor Green -NoNewline
Write-Host "to Continue... " -NoNewline
$input = Read-Host