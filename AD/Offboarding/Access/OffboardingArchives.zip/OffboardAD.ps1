﻿#**********************************************
#            Offboarding Tool                 #
#**********************************************
#        Written By Chris Rockwell            #
#**********************************************

import-module ActiveDirectory

Write-Host("`n")
$duser = Read-Host 'What is the identity [Account name ex. "crockwell"] of the User to be Offboarded?'
Write-Host("`n")
        Write-Host("********************************************************") -ForegroundColor Magenta
        Write-Host("This script will perform the following steps to the user:")
        Write-Host("Move User to") -NoNewline
        Write-Host(" 'Disabled Users'") -ForegroundColor Yellow -NoNewline
        Write-Host(" OU")
        Write-Host("Disable") -ForegroundColor Yellow -NoNewline
        Write-Host(" their AD Account")
        Write-Host("Remove") -NoNewline
        Write-Host(" ALL") -ForegroundColor Yellow -NoNewline
        Write-Host(" of group memberships except 'Domain Users'")
        Write-Host("Append 'zz' to the beginning of the users 'Name' and 'Display Name'")
        Write-Host("Ask you to reset the users password")
        Write-Host("********************************************************") -ForegroundColor Magenta
$confirm = Read-Host("Are you SURE you want to perform this action? [y/n]")
Write-Host("`n")
If($confirm -eq 'y')
    {
        $confirm2 = Read-Host("Are you REALLY SURE? [y/n]")
        Write-Host("`n")
        If($confirm2 -eq 'y')
	        {              
                Write-Host "Moving User to" -NoNewLine 
                Write-Host " Disabled Users" -ForegroundColor Yellow
                Get-ADUser $duser | Move-ADObject -targetpath (Get-ADOrganizationalUnit -filter "name -eq 'Disabled users'")
                Write-Host
                Write-Host("Complete.") -ForegroundColor Green
                Write-Host "`n"
                Write-Host "User account is being" -NoNewLine
                Write-Host " Disabled" -ForegroundColor Yellow
                Disable-ADAccount -Identity lmercer
                Write-Host
                Write-Host("Complete.") -ForegroundColor Green
            }
        If($confirm2 -eq 'y')
            {
                Write-Host `n
                Write-Host "Removing all Group Memberships except" -NoNewline
                Write-Host " 'Domain Users" -ForegroundColor Yellow
                (GET-ADUSER –Identity $duser –Properties MemberOf | Select-Object MemberOf).MemberOf | Out-File \\cgyd100379\c$\ADGroups\$duser.txt
                $User = Get-ADUser $duser -Properties memberOf
                $Groups = $User.memberOf | ForEach-Object {
                Get-ADGroup $_
                                          }
                        $Groups |ForEach-Object { 
                        Remove-ADGroupMember -Identity $_ -Members $User -Confirm:$false
                                }
                        Write-Host `n
                        Write-Host("Complete.") -ForegroundColor Green
                        Write-Host `n
            }
        If($confirm2 -eq 'y')
            {
                Write-Host "Appending" -NoNewLine
                Write-Host " 'zz'" -ForegroundColor Yellow -NoNewLine
                Write-Host " to users display names" -NoNewLine
                Set-ADuser $duser -DisplayName zz$duser
                Rename-ADObject -Identity (Get-ADUser $duser).distinguishedname -newname zz$duser
                Write-Host `n
            }
        If($confirm2 -eq 'y')
            {
                Write-Host "You will now be asked to set a New Password for" -NoNewLine
                Write-Host " $duser" -ForegroundColor Yellow
                Set-ADAccountPassword -Identity $duser -Reset
                Write-Host "`n"
            }
    }
Write-Host "`n"
Write-Host "Active Directory Process complete, press" -NoNewline
Write-Host " [Enter] " -ForegroundColor Green -NoNewline
Write-Host "to Continue... " -NoNewline
$input = Read-Host

Write-Host "`n"
Write-Host "Beginning Office365 process"
Write-Host "press" -NoNewline
Write-Host " [Enter] " -ForegroundColor Green -NoNewline
Write-Host "to Continue... "
$input = Read-Host

$UserCredential = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
Import-PSSession $Session

Import-Module MSOnline
Connect-msolservice -credential $UserCredential

$mbox = Read-Host 'What is the identity [email address] of the departing party?'
Write-Host("`n")
Get-Mailbox -identity $mbox | Get-MailboxStatistics | Select TotalItemSize
$continue = Read-Host("`nWould you like to continue with the conversion to a shared mailbox? [y/n]")
If($continue -eq 'y')
	{
		$yn = Read-Host("`nDoes anyone need access to this mailbox? [y/n]")
		Write-Host("`n")
		If($yn -eq 'y')
			{
				$access = Read-Host 'Will more than one person need access? [y/n]'
				Write-Host("`n")
				If($access -eq 'y')
					{
						$accessuser = @()
						$more = 'y'
						do
						{
							$user = Read-Host 'Please enter the user requiring access [email address(es)]'
							$accessuser += ,@($user)
							Write-Host("`n")
							$more = Read-Host 'add another? [y/n]'
							Write-Host("`n")
						}
						until($more -eq 'n')
					}
				Else
					{
						$accessuser = Read-Host 'Please enter the user to grant access [email address]'
					}
			}
		Write-Host("`n")
		$fwd = Read-Host 'Does the email need to be forwarded? [y/n]'
		If($fwd -eq 'y')
			{
				$forward = Read-Host 'Enter email address or group to forward to.'
			}
		Write-Host("`n")
		Write-Host("Changing Mailbox to Shared...")
		Get-Mailbox -identity $mbox | set-mailbox -type “Shared”
		Set-Mailbox $mbox -ProhibitSendReceiveQuota 50GB -ProhibitSendQuota 49.75GB -IssueWarningQuota 49.5GB
		Write-Host("Complete.")
		Write-Host("`n")
		If($yn -eq 'y')
			{
				Write-Host("Adding Mailbox permissions...")
				foreach ($a in $accessuser)
					{
						Add-MailboxPermission $mbox -User ((out-string -InputObject $a).Trim()) -AccessRights FullAccess
					}
				Write-Host("Complete.")
			}
		If($fwd -eq 'y')
			{
				Write-Host("Setting forwarding...")
				Set-Mailbox -Identity $mbox -ForwardingSMTPAddress $forward
				Write-Host("Complete.")
			}
 		Write-Host("Removing assigned licenses...")
		$license = (Get-MSOLUser -UserPrincipalName $mbox).Licenses[0].AccountSkuId
		Set-MsolUserLicense -UserPrincipalName $mbox -RemoveLicenses $license
        Write-Host "Process complete press" -NoNewline
        Write-Host " [Enter] " -ForegroundColor Green -NoNewline
        Write-Host "to exit: " -NoNewline
        $input = Read-Host
	}