﻿#**********************************************
# Office 365 Offboarding Tool                 #
#**********************************************
# Written By Chris Rockwell                   #
#**********************************************

$UserCredential = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
Import-PSSession $Session

Import-Module MSOnline
Connect-msolservice -credential $UserCredential

$mbox = Read-Host 'What is the identity [email address] of the departing party?'
Write-Host("`n")
Get-Mailbox -identity $mbox | Get-MailboxStatistics | Select TotalItemSize
$continue = Read-Host("`nWould you like to continue with the conversion to a shared mailbox? [y/n]")
If($continue -eq 'y')
	{
		$yn = Read-Host("`nDoes anyone need access to this mailbox? [y/n]")
		Write-Host("`n")
		If($yn -eq 'y')
			{
				$access = Read-Host 'Will more than one person need access? [y/n]'
				Write-Host("`n")
				If($access -eq 'y')
					{
						$accessuser = @()
						$more = 'y'
						do
						{
							$user = Read-Host 'Please enter the user requiring access [email address(es)]'
							$accessuser += ,@($user)
							Write-Host("`n")
							$more = Read-Host 'add another? [y/n]'
							Write-Host("`n")
						}
						until($more -eq 'n')
					}
				Else
					{
						$accessuser = Read-Host 'Please enter the user to grant access [email address]'
					}
			}
		Write-Host("`n")
		$fwd = Read-Host 'Does the email need to be forwarded? [y/n]'
		If($fwd -eq 'y')
			{
				$forward = Read-Host 'Enter email address or group to forward to.'
			}
		Write-Host("`n")
		Write-Host("Changing Mailbox to Shared...")
		Get-Mailbox -identity $mbox | set-mailbox -type “Shared”
		Set-Mailbox $mbox -ProhibitSendReceiveQuota 50GB -ProhibitSendQuota 49.75GB -IssueWarningQuota 49.5GB
		Write-Host("Complete.")
		Write-Host("`n")
		If($yn -eq 'y')
			{
				Write-Host("Adding Mailbox permissions...")
				foreach ($a in $accessuser)
					{
						Add-MailboxPermission $mbox -User ((out-string -InputObject $a).Trim()) -AccessRights FullAccess
					}
				Write-Host("Complete.")
			}
		If($fwd -eq 'y')
			{
				Write-Host("Setting forwarding...")
				Set-Mailbox -Identity $mbox -ForwardingSMTPAddress $forward
				Write-Host("Complete.")
			}
 		Write-Host("Removing assigned licenses...")
		$license = (Get-MSOLUser -UserPrincipalName $mbox).Licenses[0].AccountSkuId
		Set-MsolUserLicense -UserPrincipalName $mbox -RemoveLicenses $license
        Write-Host "Process complete press" -NoNewline
        Write-Host " [Enter] " -ForegroundColor Green -NoNewline
        Write-Host "to exit: " -NoNewline
        $input = Read-Host
	}