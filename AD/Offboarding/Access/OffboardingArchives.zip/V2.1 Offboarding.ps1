﻿#***********************************************
#             Offboarding Tool                 
#***********************************************
# Written By Chris Rockwell for AccessPipeline 
#***********************************************
#
#*************
# Change Log:
#
# V2.1 - Added section to remove user from O365 Distribution groups
#
# V2.0 - Conversion to shared was broken, fixed that
#
# V1.0.6 - Updated output to screen 
#        - Organized sections
#        - Added "to-do" reminder to end
#        - Remove Mobile devices from Exchange account access
#        - Exchange Auto-Reply set
#		 - Date entry  changed to be automatic
#		 - Clears phone numbers
#
# V1.0.5 - Logging Added 
#        - Step for removing user's Manager from AD
#
# V1.0.4 - Changed the save location of groups.csv to the new file server.
#
# V1.0.3 - Corrected bad formatting
#
# V1.0.2 - Added Note in details about disabled date 
#        - Added steps list
#        - Set Automatic Reply on Shared Mailbox
#
# V1.0.1 - Added append command to csv printout for AD groups.
#
# V1.0 - Steps included:
# Active Directory - Disable Users, Move to disabled users, Save groups as CSV and then remove, Reset Clients password
# Office 365 - Convert to Shared mailbox, Remove License, Delegate people(s) to Shared Mailbox, Forward if requested, Remove all exchange active sync mobile devices
#*************

# *********************************************************************************************
# On-Prem Activities
# *********************************************************************************************

Import-module ActiveDirectory

Start-Transcript -Append -Path "\\fskprdfile01\IT_Files\_End_User_Services\DisabledUsersGroups\Log Files\$duser.txt"

Write-Host("`n")
Write-Host 'What is the identity [Account name ex. "crockwell"] of the User to be Offboarded?' -ForegroundColor Cyan
$duser = Read-Host 

Write-Host("`n")
        Write-Host("********************************************************") -ForegroundColor Magenta
        Write-Host("This part will perform the following steps to the user:")
        Write-Host("-Move User to ") -NoNewline
        Write-Host("'Disabled Users'") -ForegroundColor Yellow -NoNewline
        Write-Host(" OU")
        Write-Host("-Disable ") -ForegroundColor Yellow -NoNewline
        Write-Host("their AD Account")
        Write-Host("-Remove ") -NoNewline
        Write-Host("ALL ") -ForegroundColor Yellow -NoNewline
        Write-Host("of group memberships except 'Domain Users'")
        Write-Host("-Append 'zz' to the beginning of the users 'Name' and 'Display Name'")
        Write-Host("-Ask you to reset the users password")
        Write-Host("-Set details for user account to current date that the user was offboarded")
		Write-Host("-Clear the Manager that is set on the user account.")
		Write-Host("-Clear all phone numbers from AD account")
        Write-Host("********************************************************") -ForegroundColor Magenta

$confirm = Read-Host("Are you sure you want to perform this action? [y/n]")
Write-Host("`n")
If($confirm -eq 'y')
    {
	$confirm2 = Read-Host("Are you REALLY SURE? [y/n]")
	Write-Host("`n")
	If($confirm2 -eq 'y')
		{
		Write-Host "Moving User to " -NoNewLine 
		Write-Host "Disabled Users" -ForegroundColor Yellow
			Get-ADUser $duser | Move-ADObject -targetpath (Get-ADOrganizationalUnit -filter "name -eq 'Disabled users'")
                
				Write-Host `n
				Write-Host("Complete.") -ForegroundColor Cyan
				Write-Host `n
		}
If($confirm -eq 'y')        
		{     
		Write-Host "User account is being " -NoNewLine
		Write-Host "Disabled " -ForegroundColor Yellow
			Disable-ADAccount -Identity $duser
            
				Write-Host `n
				Write-Host("Complete.") -ForegroundColor Cyan
				Write-Host `n
		}
If($confirm -eq 'y')		
		{
		Write-Host `n
		Write-Host "Removing all Group Memberships except " -NoNewline
		Write-Host "Domain Users " -ForegroundColor Yellow
		Write-Host "Copy of groups removed located at" -NoNewline
		Write-Host "'\\fskprdfile01\IT_Files\_End_User_Services\DisabledUsersGroups\$duser.csv'" -ForegroundColor Cyan
			(GET-ADUSER –Identity $duser –Properties MemberOf | Select-Object MemberOf).MemberOf | Out-File \\fskprdfile01\IT_Files\_End_User_Services\DisabledUsersGroups\$duser.csv -Append
			$User = Get-ADUser $duser -Properties MemberOf
			$Groups = $User.memberOf | ForEach-Object {Get-ADGroup $_}
			$Groups |ForEach-Object {Remove-ADGroupMember -Identity $_ -Members $User -Confirm:$false}
			
				Write-Host `n
				Write-Host("Complete.") -ForegroundColor Cyan
				Write-Host `n
		}
If($confirm -eq 'y')		
		{
		$date = Get-Date
		Write-Host `n
		Write-Host "Adding todays date to details section"
			Set-AdUser -Identity $duser -Description "Disabled $date"

				Write-Host `n
				Write-Host("Complete.") -ForegroundColor Cyan
				Write-Host `n
		}
If($confirm -eq 'y')		
		{
		$uname = Get-ADUser $duser | Select Name
		$uname2 = $uname.Name
		Write-Host "Appending " -NoNewLine
		Write-Host "'zz' " -ForegroundColor Yellow -NoNewLine
		Write-Host "to users display names AND clearing the users manager" -NoNewLine
			Rename-ADObject -identity (get-aduser $duser).distinguishedname -newname zz$uname2
			Set-ADUser $duser -DisplayName zz$uname2 -Manager $null

				Write-Host `n
				Write-Host("Complete.") -ForegroundColor Cyan
				Write-Host `n
		}
If($confirm -eq 'y')
		{
		Write-Host "You will now be asked to set a New Password for " -NoNewLine
		Write-Host "$duser" -ForegroundColor Yellow
			Set-ADAccountPassword -Identity $duser -Reset
			
				Write-Host `n
				Write-Host("Complete.") -ForegroundColor Cyan
				Write-Host `n
		}
If($confirm -eq 'y')
		{
		Write-Host "Clearing " -NoNewLine
		Write-Host "phone number(s) " -ForegroundColor Yellow
		Write-Host "for $duser"
			Set-ADUser $duser -MobilePhone '-' -OfficePhone '-' -HomePhone '-' -Fax '-'
		}	
	}

Write-Host "`n"
Write-Host "Active Directory Process complete, press" -NoNewline
Write-Host " [Enter] " -ForegroundColor Green -NoNewline
Write-Host "to Continue... " -NoNewline
$input = Read-Host

Stop-Transcript

# *********************************************************************************************
# Off-Prem Activities
# *********************************************************************************************

Start-Transcript -Append -Path "\\fskprdfile01\IT_Files\_End_User_Services\DisabledUsersGroups\Log Files\$duser.txt"

Write-Host "`n"
Write-Host "Beginning Office365 process"
Write-Host "press" -NoNewline
Write-Host " [Enter] " -ForegroundColor Green -NoNewline
Write-Host "to Continue... "
$input = Read-Host

$UserCredential = Get-Credential
$O365Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
Import-PSSession $O365Session

Import-Module MSOnline
Connect-msolservice -credential $UserCredential

Get-Mailbox -identity $duser"@accesspipeline.com" | Get-MailboxStatistics | Select TotalItemSize
$continue = Read-Host("`nWould you like to continue with the conversion to a shared mailbox? [y/n]")
If($continue -eq 'y')
	{
		$yn = Read-Host("`nDoes anyone need access to this mailbox? [y/n]")
		Write-Host("`n")
		If($yn -eq 'y')
		{
			$access = Read-Host 'Will more than one person need access? [y/n]'
			Write-Host("`n")
			If($access -eq 'y')
				{
					$accessuser = @()
					$more = 'y'
					do
						{
							$user = Read-Host 'Please enter the user requiring access [email address(es)]'
							$accessuser += ,@($user)
							Write-Host("`n")
							$more = Read-Host 'add another? [y/n]'
							Write-Host("`n")
						}
					until($more -eq 'n')
				}
			Else
			{
				$accessuser = Read-Host 'Please enter the user to grant access [email address]'
			}
		}
	}
		Write-Host("`n")
		$fwd = Read-Host 'Does the email need to be forwarded? [y/n]'
		If($fwd -eq 'y')
			{
				$forward = Read-Host 'Enter email address or group to forward to.'
			}
		Write-Host("`n")
		Write-Host("Changing Mailbox to Shared...")
		Get-Mailbox -identity $duser | set-mailbox -type “Shared”
		Set-Mailbox $duser -ProhibitSendReceiveQuota 50GB -ProhibitSendQuota 49.75GB -IssueWarningQuota 49.5GB
		Write-Host("Complete.")
		Write-Host("`n")
		If($yn -eq 'y')
			{
				Write-Host("Adding Mailbox permissions...")
				foreach ($a in $accessuser)
					{
						Add-MailboxPermission $duser -User ((out-string -InputObject $a).Trim()) -AccessRights FullAccess
					}
				Write-Host("Complete.")
			}
		If($fwd -eq 'y')
			{
				Write-Host("Setting forwarding...")
				Set-Mailbox -Identity $duser -ForwardingSMTPAddress $forward
				Write-Host("Complete.")
			}
	Write-Host("Removing assigned licenses...")
	$license = (Get-MSOLUser -UserPrincipalName $duser@accesspipeline.com).Licenses[0].AccountSkuId
	Set-MsolUserLicense -UserPrincipalName $duser@accesspipeline.com -RemoveLicenses $license
        
	Write-Host("Removing Mobile Devices from users Exchange account...")
		Get-MobileDevice -Mailbox $duser | ForEach {Remove-MobileDevice -Identity $_.Identity -Confirm}
                
			Write-Host `n
			Write-Host("Complete.") -ForegroundColor Cyan
			Write-Host `n

	Write-Host ("Setting Automatic Reply for $duser@accesspipeline.com")
		Set-MailboxAutoReplyConfiguration $duser@accesspipeline.com -AutoReplyState Enabled -InternalMessage "Please be informed that this person is no longer with Access Pipeline.  If this is an important, Access Pipeline business related matter please email their manager at '$accessuser'" -ExternalMessage "Please be informed that this person is no longer with Access Pipeline.  If this is an important, Access Pipeline business related matter please email their manager at '$accessuser'"
                
			Write-Host `n
			Write-Host("Complete.") -ForegroundColor Cyan
			Write-Host `n
        
		
	Write-Host ("Removing user from all O365 Distribution Groups")
	
		$adname = (get-aduser $duser).name
		$mailbox = get-mailbox $duser
		$dgs = Get-DistributionGroup
 
		foreach($dg in $dgs){
			$DGMs = Get-DistributionGroupMember -identity $dg.Identity
				foreach ($dgm in $DGMs) {if ($dgm.name -eq $mailbox.name)
					{"Removing $user from Group $dg.identity"
					Remove-DistributionGroupMember $dg.Name -Member $duser@accesspipeline.com
				}
			}
		}
		
			Write-Host `n
			Write-Host("Complete.") -ForegroundColor Cyan
			Write-Host `n
		
    Write-Host "Process complete, press" -NoNewline
    Write-Host " [Enter]"  -ForegroundColor Green -NoNewline
    Write-Host " To end..."
    Read-Host 
	
    Remove-PSSession $O365Session

Stop-Transcript    
            
			Write-Host `n
            Write-Host "******************************************" -ForegroundColor Red
            Write-Host "Tasks remaining" -ForegroundColor Cyan
            Write-Host "******************************************" -ForegroundColor Red
            Write-Host "KMI" -ForegroundColor White
            Write-Host "Exchange 2010 - Hide Mailbox" -ForegroundColor White
            Write-Host "Transfer P:\ Drives" -ForegroundColor White
            Write-Host "Phone settings" -ForegroundColor White
            Write-Host "Equipment Pickups and Spreadsheet updates" -ForegroundColor White
            Write-Host "******************************************" -ForegroundColor Red