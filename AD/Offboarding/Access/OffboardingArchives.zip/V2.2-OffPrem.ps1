Write-Host 'What is the identity [Account name ex. "crockwell"] of the User to be Offboarded?' -ForegroundColor Cyan
$duser = Read-Host 

# *********************************************************************************************
# Off-Prem Activities
# *********************************************************************************************

Start-Transcript -Append -Path "\\fskprdfile01\IT_Files\_End_User_Services\DisabledUsersGroups\Log Files\$duser.txt"

Write-Host "`n"
Write-Host "Beginning Office365 process"
Write-Host "press" -NoNewline
Write-Host " [Enter] " -ForegroundColor Green -NoNewline
Write-Host "to Continue... "
$input = Read-Host

$UserCredential = Get-Credential crockwell@accesspipeline.com
$O365Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection
Import-PSSession $O365Session

Import-Module MSOnline
Connect-msolservice -credential $UserCredential

Get-Mailbox -identity $duser"@accesspipeline.com" | Get-MailboxStatistics | Select TotalItemSize
$continue = Read-Host("`nWould you like to continue with the conversion to a shared mailbox? [y/n]")
If($continue -eq 'y')
	{   Write-Host ("Does anyone need access to this mailbox? ") -NoNewline
		Write-Host ("[y/n] ") -ForegroundColor Yellow -NoNewLine
        $yn = Read-Host 
		Write-Host("`n")
		If($yn -eq 'y')

		{
			Write-Host ("Please enter the user to grant access ") -NoNewline
			Write-Host ("[email address] ") -ForegroundColor Yellow -NoNewLine
			$accessuser = Read-Host 
		}
		
	}
		
		Write-Host("`n")
		Write-Host("Changing Mailbox to Shared...")
		Get-Mailbox -identity $duser | set-mailbox -type “Shared”
		Set-Mailbox $duser -ProhibitSendReceiveQuota 50GB -ProhibitSendQuota 49.75GB -IssueWarningQuota 49.5GB
        
            Write-Host("`n")		
            Write-Host("Complete.") -ForegroundColor Cyan
		    Write-Host("`n")

		If($yn -eq 'y')
			{
				Write-Host("Adding Mailbox permissions...")
				foreach ($a in $accessuser)
					{
						Add-MailboxPermission $duser -User ((out-string -InputObject $a).Trim()) -AccessRights FullAccess
					}
        	    
            Write-Host `n
			Write-Host("Complete.") -ForegroundColor Cyan
			Write-Host `n
			
            }
		
	Write-Host("Removing assigned licenses...")
	$license = (Get-MSOLUser -UserPrincipalName $duser@accesspipeline.com).Licenses[0].AccountSkuId
	Set-MsolUserLicense -UserPrincipalName $duser@accesspipeline.com -RemoveLicenses $license
        
        	Write-Host `n
			Write-Host("Complete.") -ForegroundColor Cyan
			Write-Host `n

	Write-Host("Removing Mobile Devices from users Exchange account...")
		Get-MobileDevice -Mailbox $duser@accesspipeline.com | ForEach {Remove-MobileDevice -Identity $_.Identity}
                
			Write-Host `n
			Write-Host("Complete.") -ForegroundColor Cyan
			Write-Host `n

	Write-Host ("Setting Automatic Reply for $duser@accesspipeline.com")
		Set-MailboxAutoReplyConfiguration $duser@accesspipeline.com -AutoReplyState Enabled -InternalMessage "Please be informed that this person is no longer with Access Pipeline.  If this is an important, Access Pipeline business related matter please email their manager at '$accessuser'" -ExternalMessage "Please be informed that this person is no longer with Access Pipeline.  If this is an important, Access Pipeline business related matter please email their manager at '$accessuser'"
                
			Write-Host `n
			Write-Host("Complete.") -ForegroundColor Cyan
			Write-Host `n
        
		
	Write-Host ("Removing user from all O365 Distribution Groups")
	
		$adname = (get-aduser $duser).name
		$mailbox = get-mailbox $duser
		$dgs = Get-DistributionGroup
 
		foreach($dg in $dgs)
		{
			$DGMs = Get-DistributionGroupMember -identity $dg.Identity
				foreach ($dgm in $DGMs){if ($dgm.name -eq $mailbox.name)
					{"Removing $user from Group $dg.identity"
					Remove-DistributionGroupMember $dg.Name -Member $duser@accesspipeline.com
				}
			}
		}
		
			Write-Host `n
			Write-Host("Complete.") -ForegroundColor Cyan
			Write-Host `n
		
    Write-Host "Process complete, press" -NoNewline
    Write-Host " [Enter]"  -ForegroundColor Green -NoNewline
    Write-Host " To end..."
    Read-Host 
	
    Remove-PSSession $O365Session