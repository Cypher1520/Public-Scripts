@echo off

:execute
powershell -executionpolicy bypass -file .\waitforuserdeviceregistration.ps1

:quit