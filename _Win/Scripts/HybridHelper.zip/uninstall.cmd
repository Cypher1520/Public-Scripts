@echo off

:delete_tag
del /f c:\ProgramData\AutopilotConfig\WaitForUserDeviceRegistration.tag

:quit